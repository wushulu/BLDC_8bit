/* 
 * File:   motor.h
 * Author: C16195
 *
 * Created on September 28, 2016, 3:24 PM
 */

#ifndef MOTOR_H
#define	MOTOR_H

#include <stdint.h>
#include "speedController.h"

/**
 * Init a motor
 * @return 0 if success
 */
int motorInit();

/**
 * Start a motor
 * @return 0 if success
 */
int motorStart();

/**
 * Stop a motor
 * @return 0 if success
 */
int motorStop();

/**
 * Set a speed reference of a motor
 * @param target speed
 * @return 0 if success
 */
int motorSetSpeed(uint16_t speed);

/**
 * Set the max speed reference of a motor
 * @param target speed
 */
void motorSetMaxSpeed(uint16_t maxSpeed);

/**
 * Set the max speed reference of a motor
 * @param target speed
 */
void motorSetMinSpeed(uint16_t minSpeed);


/**
 * Get motor state
 * @return state of the motor, as MotorState type
 */
const char* motorGetState();

/**
 * Set speed controller
 * @param ctrl
 * @return 0 if success
 */
int motorSetSpeedController(IController ctrl);

/**
 * Run motor control loop once, should be place in main loop or a timer isr
 */
void motorSpin();

#endif	/* MOTOR_H */

