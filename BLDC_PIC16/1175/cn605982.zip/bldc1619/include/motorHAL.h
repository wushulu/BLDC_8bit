/* 
 * File:   motorHAL.h
 * Author: C16195
 *
 * Created on October 3, 2016, 3:24 PM
 */

#ifndef MOTORHAL_H
#define	MOTORHAL_H

#include <stdint.h>
#include <stdbool.h>

#define REG_PWMDUTY PWM3DCH
#define ZERO_CROSS_CHECK() CMP1_GetOutputStatus()

#define CWG_STATUS_U CWG1OCON0bits.CWG1STRA
#define CWG_STATUS_V CWG1OCON0bits.CWG1STRB
#define CWG_STATUS_W CWG1OCON0bits.CWG1STRD

void  motorHAL_setSpeed(uint16_t _minSpeed);              
bool motorHAL_zeroCross(void);

void UHon(void);
void UHoff(void);
void ULon(void);
void ULoff(void);
void VHon(void);
void VHoff(void);
void VLon(void);
void VLoff(void);
void WHon(void);
void WHoff(void);
void WLon(void);
void WLoff(void);



#endif	/* MOTORHAL_H */

