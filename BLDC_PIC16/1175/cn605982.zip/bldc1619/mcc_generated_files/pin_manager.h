/**
  @Generated Pin Manager Header File

  @Company:
    Microchip Technology Inc.

  @File Name:
    pin_manager.h

  @Summary:
    This is the Pin Manager file generated using MPLAB(c) Code Configurator

  @Description:
    This header file provides implementations for pin APIs for all pins selected in the GUI.
    Generation Information :
        Product Revision  :  MPLAB(c) Code Configurator - 3.15.0
        Device            :  PIC16F1619
        Version           :  1.01
    The generated drivers are tested against the following:
        Compiler          :  XC8 1.35
        MPLAB             :  MPLAB X 3.20

    Copyright (c) 2013 - 2015 released Microchip Technology Inc.  All rights reserved.

    Microchip licenses to you the right to use, modify, copy and distribute
    Software only when embedded on a Microchip microcontroller or digital signal
    controller that is integrated into your product or third party product
    (pursuant to the sublicense terms in the accompanying license agreement).

    You should refer to the license agreement accompanying this Software for
    additional information regarding your rights and obligations.

    SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
    EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
    MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
    IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
    CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
    OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
    INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
    CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
    SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
    (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

*/


#ifndef PIN_MANAGER_H
#define PIN_MANAGER_H

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set PWMH3 aliases
#define PWMH3_TRIS               TRISA5
#define PWMH3_LAT                LATA5
#define PWMH3_PORT               RA5
#define PWMH3_WPU                WPUA5
#define PWMH3_SetHigh()    do { LATA5 = 1; } while(0)
#define PWMH3_SetLow()   do { LATA5 = 0; } while(0)
#define PWMH3_Toggle()   do { LATA5 = ~LATA5; } while(0)
#define PWMH3_GetValue()         PORTAbits.RA5
#define PWMH3_SetDigitalInput()    do { TRISA5 = 1; } while(0)
#define PWMH3_SetDigitalOutput()   do { TRISA5 = 0; } while(0)

#define PWMH3_SetPullup()    do { WPUA5 = 1; } while(0)
#define PWMH3_ResetPullup()   do { WPUA5 = 0; } while(0)


// get/set Debug aliases
#define Debug_TRIS               TRISB4
#define Debug_LAT                LATB4
#define Debug_PORT               RB4
#define Debug_WPU                WPUB4
#define Debug_ANS                ANSB4
#define Debug_SetHigh()    do { LATB4 = 1; } while(0)
#define Debug_SetLow()   do { LATB4 = 0; } while(0)
#define Debug_Toggle()   do { LATB4 = ~LATB4; } while(0)
#define Debug_GetValue()         PORTBbits.RB4
#define Debug_SetDigitalInput()    do { TRISB4 = 1; } while(0)
#define Debug_SetDigitalOutput()   do { TRISB4 = 0; } while(0)

#define Debug_SetPullup()    do { WPUB4 = 1; } while(0)
#define Debug_ResetPullup()   do { WPUB4 = 0; } while(0)
#define Debug_SetAnalogMode()   do { ANSB4 = 1; } while(0)
#define Debug_SetDigitalMode()   do { ANSB4 = 0; } while(0)


// get/set SW3 aliases
#define SW3_TRIS               TRISB5
#define SW3_LAT                LATB5
#define SW3_PORT               RB5
#define SW3_WPU                WPUB5
#define SW3_ANS                ANSB5
#define SW3_SetHigh()    do { LATB5 = 1; } while(0)
#define SW3_SetLow()   do { LATB5 = 0; } while(0)
#define SW3_Toggle()   do { LATB5 = ~LATB5; } while(0)
#define SW3_GetValue()         PORTBbits.RB5
#define SW3_SetDigitalInput()    do { TRISB5 = 1; } while(0)
#define SW3_SetDigitalOutput()   do { TRISB5 = 0; } while(0)

#define SW3_SetPullup()    do { WPUB5 = 1; } while(0)
#define SW3_ResetPullup()   do { WPUB5 = 0; } while(0)
#define SW3_SetAnalogMode()   do { ANSB5 = 1; } while(0)
#define SW3_SetDigitalMode()   do { ANSB5 = 0; } while(0)


// get/set SW2 aliases
#define SW2_TRIS               TRISB6
#define SW2_LAT                LATB6
#define SW2_PORT               RB6
#define SW2_WPU                WPUB6
#define SW2_ANS                ANSB6
#define SW2_SetHigh()    do { LATB6 = 1; } while(0)
#define SW2_SetLow()   do { LATB6 = 0; } while(0)
#define SW2_Toggle()   do { LATB6 = ~LATB6; } while(0)
#define SW2_GetValue()         PORTBbits.RB6
#define SW2_SetDigitalInput()    do { TRISB6 = 1; } while(0)
#define SW2_SetDigitalOutput()   do { TRISB6 = 0; } while(0)

#define SW2_SetPullup()    do { WPUB6 = 1; } while(0)
#define SW2_ResetPullup()   do { WPUB6 = 0; } while(0)
#define SW2_SetAnalogMode()   do { ANSB6 = 1; } while(0)
#define SW2_SetDigitalMode()   do { ANSB6 = 0; } while(0)


// get/set SW1 aliases
#define SW1_TRIS               TRISB7
#define SW1_LAT                LATB7
#define SW1_PORT               RB7
#define SW1_WPU                WPUB7
#define SW1_ANS                ANSB7
#define SW1_SetHigh()    do { LATB7 = 1; } while(0)
#define SW1_SetLow()   do { LATB7 = 0; } while(0)
#define SW1_Toggle()   do { LATB7 = ~LATB7; } while(0)
#define SW1_GetValue()         PORTBbits.RB7
#define SW1_SetDigitalInput()    do { TRISB7 = 1; } while(0)
#define SW1_SetDigitalOutput()   do { TRISB7 = 0; } while(0)

#define SW1_SetPullup()    do { WPUB7 = 1; } while(0)
#define SW1_ResetPullup()   do { WPUB7 = 0; } while(0)
#define SW1_SetAnalogMode()   do { ANSB7 = 1; } while(0)
#define SW1_SetDigitalMode()   do { ANSB7 = 0; } while(0)


// get/set SW1 aliases
#define SW1_TRIS               TRISB7
#define SW1_LAT                LATB7
#define SW1_PORT               RB7
#define SW1_WPU                WPUB7
#define SW1_ANS                ANSB7
#define SW1_SetHigh()    do { LATB7 = 1; } while(0)
#define SW1_SetLow()   do { LATB7 = 0; } while(0)
#define SW1_Toggle()   do { LATB7 = ~LATB7; } while(0)
#define SW1_GetValue()         PORTBbits.RB7
#define SW1_SetDigitalInput()    do { TRISB7 = 1; } while(0)
#define SW1_SetDigitalOutput()   do { TRISB7 = 0; } while(0)

#define SW1_SetPullup()    do { WPUB7 = 1; } while(0)
#define SW1_ResetPullup()   do { WPUB7 = 0; } while(0)
#define SW1_SetAnalogMode()   do { ANSB7 = 1; } while(0)
#define SW1_SetDigitalMode()   do { ANSB7 = 0; } while(0)


// get/set SW1 aliases
#define SW1_TRIS               TRISB7
#define SW1_LAT                LATB7
#define SW1_PORT               RB7
#define SW1_WPU                WPUB7
#define SW1_ANS                ANSB7
#define SW1_SetHigh()    do { LATB7 = 1; } while(0)
#define SW1_SetLow()   do { LATB7 = 0; } while(0)
#define SW1_Toggle()   do { LATB7 = ~LATB7; } while(0)
#define SW1_GetValue()         PORTBbits.RB7
#define SW1_SetDigitalInput()    do { TRISB7 = 1; } while(0)
#define SW1_SetDigitalOutput()   do { TRISB7 = 0; } while(0)

#define SW1_SetPullup()    do { WPUB7 = 1; } while(0)
#define SW1_ResetPullup()   do { WPUB7 = 0; } while(0)
#define SW1_SetAnalogMode()   do { ANSB7 = 1; } while(0)
#define SW1_SetDigitalMode()   do { ANSB7 = 0; } while(0)


// get/set SW1 aliases
#define SW1_TRIS               TRISB7
#define SW1_LAT                LATB7
#define SW1_PORT               RB7
#define SW1_WPU                WPUB7
#define SW1_ANS                ANSB7
#define SW1_SetHigh()    do { LATB7 = 1; } while(0)
#define SW1_SetLow()   do { LATB7 = 0; } while(0)
#define SW1_Toggle()   do { LATB7 = ~LATB7; } while(0)
#define SW1_GetValue()         PORTBbits.RB7
#define SW1_SetDigitalInput()    do { TRISB7 = 1; } while(0)
#define SW1_SetDigitalOutput()   do { TRISB7 = 0; } while(0)

#define SW1_SetPullup()    do { WPUB7 = 1; } while(0)
#define SW1_ResetPullup()   do { WPUB7 = 0; } while(0)
#define SW1_SetAnalogMode()   do { ANSB7 = 1; } while(0)
#define SW1_SetDigitalMode()   do { ANSB7 = 0; } while(0)


// get/set FAULT aliases
#define FAULT_TRIS               TRISC4
#define FAULT_LAT                LATC4
#define FAULT_PORT               RC4
#define FAULT_WPU                WPUC4
#define FAULT_SetHigh()    do { LATC4 = 1; } while(0)
#define FAULT_SetLow()   do { LATC4 = 0; } while(0)
#define FAULT_Toggle()   do { LATC4 = ~LATC4; } while(0)
#define FAULT_GetValue()         PORTCbits.RC4
#define FAULT_SetDigitalInput()    do { TRISC4 = 1; } while(0)
#define FAULT_SetDigitalOutput()   do { TRISC4 = 0; } while(0)

#define FAULT_SetPullup()    do { WPUC4 = 1; } while(0)
#define FAULT_ResetPullup()   do { WPUC4 = 0; } while(0)


// get/set FAULT aliases
#define FAULT_TRIS               TRISC4
#define FAULT_LAT                LATC4
#define FAULT_PORT               RC4
#define FAULT_WPU                WPUC4
#define FAULT_SetHigh()    do { LATC4 = 1; } while(0)
#define FAULT_SetLow()   do { LATC4 = 0; } while(0)
#define FAULT_Toggle()   do { LATC4 = ~LATC4; } while(0)
#define FAULT_GetValue()         PORTCbits.RC4
#define FAULT_SetDigitalInput()    do { TRISC4 = 1; } while(0)
#define FAULT_SetDigitalOutput()   do { TRISC4 = 0; } while(0)

#define FAULT_SetPullup()    do { WPUC4 = 1; } while(0)
#define FAULT_ResetPullup()   do { WPUC4 = 0; } while(0)


// get/set PWMH2 aliases
#define PWMH2_TRIS               TRISC6
#define PWMH2_LAT                LATC6
#define PWMH2_PORT               RC6
#define PWMH2_WPU                WPUC6
#define PWMH2_ANS                ANSC6
#define PWMH2_SetHigh()    do { LATC6 = 1; } while(0)
#define PWMH2_SetLow()   do { LATC6 = 0; } while(0)
#define PWMH2_Toggle()   do { LATC6 = ~LATC6; } while(0)
#define PWMH2_GetValue()         PORTCbits.RC6
#define PWMH2_SetDigitalInput()    do { TRISC6 = 1; } while(0)
#define PWMH2_SetDigitalOutput()   do { TRISC6 = 0; } while(0)

#define PWMH2_SetPullup()    do { WPUC6 = 1; } while(0)
#define PWMH2_ResetPullup()   do { WPUC6 = 0; } while(0)
#define PWMH2_SetAnalogMode()   do { ANSC6 = 1; } while(0)
#define PWMH2_SetDigitalMode()   do { ANSC6 = 0; } while(0)


// get/set PWMH1 aliases
#define PWMH1_TRIS               TRISC7
#define PWMH1_LAT                LATC7
#define PWMH1_PORT               RC7
#define PWMH1_WPU                WPUC7
#define PWMH1_ANS                ANSC7
#define PWMH1_SetHigh()    do { LATC7 = 1; } while(0)
#define PWMH1_SetLow()   do { LATC7 = 0; } while(0)
#define PWMH1_Toggle()   do { LATC7 = ~LATC7; } while(0)
#define PWMH1_GetValue()         PORTCbits.RC7
#define PWMH1_SetDigitalInput()    do { TRISC7 = 1; } while(0)
#define PWMH1_SetDigitalOutput()   do { TRISC7 = 0; } while(0)

#define PWMH1_SetPullup()    do { WPUC7 = 1; } while(0)
#define PWMH1_ResetPullup()   do { WPUC7 = 0; } while(0)
#define PWMH1_SetAnalogMode()   do { ANSC7 = 1; } while(0)
#define PWMH1_SetDigitalMode()   do { ANSC7 = 0; } while(0)



/**
 * @Param
    none
 * @Returns
    none
 * @Description
    GPIO and peripheral I/O initialization
 * @Example
    PIN_MANAGER_Initialize();
 */
void PIN_MANAGER_Initialize (void);

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handling routine
 * @Example
    PIN_MANAGER_IOC();
 */
void PIN_MANAGER_IOC(void);

#endif // PIN_MANAGER_H
/**
 End of File
*/