#include <stdint.h>
#include <stdlib.h>
#include "motor.h"
#include "motorHAL.h"
#include "motorBLDC_6step_feedback.h"
#include "speedController.h"
#include "mcc.h"
/**
 * Implementation specific motor structure
 */
// COMMUTATION TIMEOUT IF NO ZC DETECTED

#define FILTER_DELAY 6 
#define MAX_RampSpeed 0x005f
#define MAX_CommTime  0x2FF

typedef enum 
{
    COMM_OFF, 
    COMM_STEP1, COMM_STEP2, 
    COMM_STEP3, COMM_STEP4, 
    COMM_STEP5, COMM_STEP6, 
    COMM_STEPOVER
} CommuState;

typedef enum 
{
    MOTOR_INIT = 0,
    MOTOR_STARTUP,
    MOTOR_RUN,
    MOTOR_STOP,
    MOTOR_TOTAL_STATE            
} MotorState;

typedef enum 
{
    FRONT, 
    REVERSE
} direction_t;

static uint16_t        comm_time; /* communication time */
static int16_t         phase_delay_counter;
static uint16_t        phase_delay;
static uint32_t        phase_delay_filter;
static uint8_t         zc_detected;
static CommuState      comm_state = COMM_OFF;
static direction_t     direction = FRONT;
static uint8_t         bemf_filter;
static uint16_t        Speed;
static uint16_t        SetPoint;
static MotorState      run_state = MOTOR_STOP;

static uint16_t _maxSpeed = 0x00FF;
static uint16_t _minSpeed = 0x0025;

static IController speedController = openLoopController;
static uint16_t speedFeedback = 0;

// Handle Gates
typedef void (*GateHandler)(void);
typedef struct {
    GateHandler drive[6];
} GateState_t;
static const GateState_t gateStates[] = {
    {UHoff, ULoff, VHoff, VLoff, WHoff, WLoff},
    {ULoff, VHoff, WHoff, WLoff, UHon, VLon},
    {ULoff, VHoff, VLoff, WHoff, UHon, WLon},
    {UHoff, ULoff, VLoff, WHoff, VHon, WLon},
    {UHoff, VLoff, WHoff, WLoff, VHon, ULon},
    {UHoff, VHoff, VLoff, WLoff, WHon, ULon},
    {UHoff, ULoff, VHoff, WLoff, WHon, VLon},
    {UHoff, ULoff, VHoff, VLoff, WHoff, WLoff},
};

// Handle Feedbacks
typedef void (*FeedbackMonitor)(void);
typedef void (*FeedbackPolarity)(void);
typedef struct {
    FeedbackMonitor drive;
} FeedbackMonitor_t;
typedef struct {
    FeedbackPolarity drive[2];
} FeedbackPolarity_t;
static const FeedbackMonitor_t feedbackMonitor[] = {
    FeedbackW, FeedbackW, FeedbackV, FeedbackU, FeedbackW, FeedbackV, FeedbackU, FeedbackW
};
static const FeedbackPolarity_t feedbackPolarity[] = {
    {ComparePolarityPos, ComparePolarityNeg},
    {ComparePolarityNeg, ComparePolarityPos},
    {ComparePolarityPos, ComparePolarityNeg},
    {ComparePolarityNeg, ComparePolarityPos},
    {ComparePolarityPos, ComparePolarityNeg},
    {ComparePolarityNeg, ComparePolarityPos},
    {ComparePolarityPos, ComparePolarityNeg},
    {ComparePolarityNeg, ComparePolarityPos},
};

static int motorRun(void);
static int motorStartUp(void);
static void PositionHandler(void);
static void Commutate(void);
static void PhaseDelayFilter(void);
static void UpdateState(void);
static void HandleGates(CommuState state);
static void HandleFeedbacks(CommuState state, direction_t motor_direction);

typedef int (*RunState)(void);
typedef struct {
    RunState drive;
}RunState_t;
static const RunState_t runState[] = {
    {motorStart}, {motorStartUp}, {motorRun}, {motorStop}
};

/*************** Public Functions *****************/
int motorInit()
{
    TMR2_SetInterruptHandler(motorSpin);
    direction = FRONT; //Note that Motor direction depends on the Wiring
    run_state = MOTOR_STOP;
    INTERRUPT_PeripheralInterruptEnable();
    INTERRUPT_GlobalInterruptEnable();  
}

int motorStart()
{
    comm_state = COMM_STEP1;
    comm_time = 0;
    bemf_filter = 0;
    phase_delay_filter = 0;
    phase_delay_counter = 0;
    phase_delay = 0;
    zc_detected = 0;
    motorHAL_setSpeed(_minSpeed);              
    run_state = MOTOR_STARTUP;
    return 0;
}

int motorStop()
{
    HandleGates(COMM_OFF); //Turn OFF 3 ph Bridge Switches
    run_state = MOTOR_STOP;
    return 0;
}

int motorSetSpeed(uint16_t speed)
{
    SetPoint = speed;
    return 0;
}

void motorSetMaxSpeed(uint16_t maxSpeed)
{
    _maxSpeed = maxSpeed;
}

void motorSetMinSpeed(uint16_t minSpeed)
{
    _minSpeed = minSpeed;
}

const char* motorGetState()
{
    return "NA";
}


void motorSpin()
{
    if(run_state != MOTOR_STOP){
        PositionHandler();
    }
    runState[run_state].drive();
}

int motorSetSpeedController(IController ctrl)
{
    if (ctrl != NULL){
        speedController = ctrl;
        return 0;
    }
    return -1;
}

// Majority Detect Filter
static const unsigned char cBEMF_FILTER[64]={0x00,0x02,0x04,0x06,0x08,0x0A,0x0C,0x0E,0x10,0x12,0x14,0x16,0x18,0x1A,0x1C,0x1E,
									  0x20,0x22,0x24,0x26,0x28,0x2A,0x2C,0x2E,0x01,0x01,0x01,0x36,0x01,0x3A,0x3C,0x3E,
									  0x00,0x02,0x04,0x06,0x08,0x0A,0x0C,0x0E,0x01,0x01,0x01,0x16,0x01,0x1A,0x1C,0x1E,
									  0x01,0x01,0x01,0x26,0x01,0x2A,0x2C,0x2E,0x01,0x01,0x01,0x36,0x01,0x3A,0x3C,0x3E};

/*************** Private Functions *****************/
static int motorStartUp(void)
{
    if ((Speed < MAX_RampSpeed)){ // Generate a start up ramp for PWM duty
        motorHAL_setSpeed(++Speed);
    } else {
        run_state = MOTOR_RUN;
    }
    return 0;
}

static int motorRun(void){
    uint16_t setp;
    setp = speedController(SetPoint,speedFeedback);
    if (setp < _minSpeed) {
        motorHAL_setSpeed(_minSpeed);
    } else if (setp >= _maxSpeed) {
        motorHAL_setSpeed(_maxSpeed);
    } else  {
        motorHAL_setSpeed(setp);
    }
    return 0;
}

static void PositionHandler(void)
{
    ++comm_time;
    if (motorHAL_zeroCross()) bemf_filter |= 0b00000001;
    bemf_filter = cBEMF_FILTER[bemf_filter];
    if (bemf_filter & 0b00000001) zc_detected = 1;
    if (zc_detected) {
        if (!(phase_delay_counter--)) {
            Commutate();
        }
    }
    if (comm_time > MAX_CommTime) {
        Commutate();
    }
}

static void Commutate(void)
{
    speedFeedback = _maxSpeed / comm_time;
    PhaseDelayFilter();
    zc_detected = 0;
    bemf_filter = 0;
    comm_time = 0;
    HandleGates(comm_state);
    HandleFeedbacks(comm_state, direction);
    UpdateState();   
}

static void PhaseDelayFilter(void)
{
    phase_delay_filter += comm_time;
    phase_delay = phase_delay_filter >> FILTER_DELAY;
    phase_delay_filter -= phase_delay;
    phase_delay_counter = phase_delay >> 3;
}

static void HandleGates(CommuState state)
{
    gateStates[state].drive[0]();
    gateStates[state].drive[1]();
    gateStates[state].drive[2]();
    gateStates[state].drive[3]();
    gateStates[state].drive[4]();
    gateStates[state].drive[5]();
}

static void UpdateState(void)
{
    if (direction == FRONT) {
        if (++comm_state > COMM_STEP6) {
            comm_state = COMM_STEP1;
        }
    } else {
        if (--comm_state < COMM_STEP1) {
            comm_state = COMM_STEP6;
        }
    }
}

static void HandleFeedbacks(CommuState state, direction_t motor_direction)
{
    feedbackMonitor[state].drive();
    feedbackPolarity[state].drive[motor_direction]();
}
