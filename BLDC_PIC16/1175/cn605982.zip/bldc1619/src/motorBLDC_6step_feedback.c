#include "motorBLDC_6step_feedback.h"
#include "mcc.h"

void FeedbackU(void){
    CM1CON1 = 0x00;
}
void FeedbackV(void){
    CM1CON1 = 0x01;
}
void FeedbackW(void){
    CM1CON1 = 0x02;
}
void ComparePolarityPos(void){
    CM1CON0 = 0x80;
}
void ComparePolarityNeg(void){
    CM1CON0 = 0x90;
}