#include <stdbool.h>
#include "motorHAL.h"
#include "mcc.h"

void  motorHAL_setSpeed(uint16_t duty){
    PWM3DCH = (duty & 0x00ff);
}

bool motorHAL_zeroCross(void){
    return (CMP1_GetOutputStatus() == 1);
}

void UHon(void){
    PWMH1_SetHigh();
}
void UHoff(void){
    PWMH1_SetLow();
}
void ULon(void){
    CWG1OCON0bits.CWG1STRA = 1;
}
void ULoff(void){
    CWG1OCON0bits.CWG1STRA = 0;
}

void VHon(void){
    PWMH2_SetHigh();
}
void VHoff(void){
    PWMH2_SetLow();
}
void VLon(void){
    CWG1OCON0bits.CWG1STRB = 1;
}
void VLoff(void){
    CWG1OCON0bits.CWG1STRB = 0;
}

void WHon(void){
    PWMH3_SetHigh();
}
void WHoff(void){
    PWMH3_SetLow();
}
void WLon(void){
    CWG1OCON0bits.CWG1STRD = 1;
}
void WLoff(void){
    CWG1OCON0bits.CWG1STRD = 0;
}

