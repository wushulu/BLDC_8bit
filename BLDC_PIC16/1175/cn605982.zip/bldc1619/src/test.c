#include "motor.h"
#include "mcc.h"

void test(void)
{
   
    while (1)
    {
        if (!SW2_PORT) {
            ADC_StartConversion(POT);//Initiate an initial conversion and set the Channel
            motorStart();
        }
        // Add your application code
        if (!SW3_PORT) {    
            motorStop();
        }
        motorSetSpeed(ADC_GetConversion(POT) >> 8);
        
    }
}
