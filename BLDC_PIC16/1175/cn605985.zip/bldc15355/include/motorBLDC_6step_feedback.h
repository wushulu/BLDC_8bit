/* 
 * File:   motorBLDC_6step.h
 * Author: C16195
 *
 * Created on October 10, 2016, 2:31 PM
 */

#ifndef MOTORBLDC_6STEP_H
#define	MOTORBLDC_6STEP_H

#define REG_FB CM1CON0

void FeedbackU(void);
void FeedbackV(void);
void FeedbackW(void);
void ComparePolarityPos(void);
void ComparePolarityNeg(void);

#endif	/* MOTORBLDC_6STEP_H */

