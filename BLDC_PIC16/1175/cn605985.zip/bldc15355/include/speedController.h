/* 
 * File:   speedController.h
 * Author: C16195
 *
 * Created on October 10, 2016, 2:45 PM
 */

#ifndef SPEEDCONTROLLER_H
#define	SPEEDCONTROLLER_H

#include <stdint.h>

typedef uint16_t (*IController)(uint16_t setp, uint16_t feedback);

uint16_t openLoopController(uint16_t setp, uint16_t feedback);
uint16_t swPIDController(uint16_t setp, uint16_t feedback);

#endif	/* SPEEDCONTROLLER_H */

