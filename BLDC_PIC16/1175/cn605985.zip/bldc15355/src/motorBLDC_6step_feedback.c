#include "motorBLDC_6step_feedback.h"
#include "mcc.h"

void FeedbackU(void){
    CM1NCH = 0x00;
}
void FeedbackV(void){
    CM1NCH = 0x01;
}
void FeedbackW(void){
    CM1NCH = 0x03;
}
void ComparePolarityPos(void){
    REG_FB = 0x80;
}
void ComparePolarityNeg(void){
    REG_FB = 0x90;
}