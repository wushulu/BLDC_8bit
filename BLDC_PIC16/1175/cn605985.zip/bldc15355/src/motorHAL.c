#include <stdbool.h>
#include "motorHAL.h"
#include "mcc.h"

void  motorHAL_setSpeed(uint16_t duty){
    REG_PWMDUTY = (duty & 0x00ff);
}

bool motorHAL_zeroCross(void){
    return (ZERO_CROSS_CHECK() == 1);
}

void UHon(void){
    PWMH1_SetHigh();
}
void UHoff(void){
    PWMH1_SetLow();
}
void ULon(void){
    CWG_STATUS_U = 1;
}
void ULoff(void){
    CWG_STATUS_U = 0;
}

void VHon(void){
    PWMH2_SetHigh();
}
void VHoff(void){
    PWMH2_SetLow();
}
void VLon(void){
    CWG_STATUS_V = 1;
}
void VLoff(void){
    CWG_STATUS_V = 0;
}

void WHon(void){
    PWMH3_SetHigh();
}
void WHoff(void){
    PWMH3_SetLow();
}
void WLon(void){
    CWG_STATUS_W = 1;
}
void WLoff(void){
    CWG_STATUS_W = 0;
}

