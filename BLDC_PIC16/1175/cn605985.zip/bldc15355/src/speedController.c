#include "speedController.h"

uint16_t openLoopController(uint16_t setp, uint16_t feedback)
{
    (void) feedback;
    return setp;
}

uint16_t swPIDController(uint16_t setp, uint16_t feedback)
{
    static uint8_t k1 = 30;
    static uint8_t k2 = 12;
    static uint8_t k3 = 1;
    static int32_t out = 0;
    
    static int16_t e = 0;
    static int16_t edot = 0;
    static int16_t eddot = 0;
    
    e = feedback - setp;
    out += e*k1 + edot*k2 + eddot*k3;
    eddot = edot;
    edot = e;

    return (out>>11);
}